
public class Cir_SLL {
	Node_SLL head = new Node_SLL(5);
	Node_SLL temp = head;
	temp.next = head;
	void insert_after(int x)
	{
		Node_SLL new_node = new Node_SLL(x);
		temp.next = new_node;
		new_node.next = temp.next.next;;
	}
	void print()
	{
		while(temp.next!=head)
		{
			System.out.print(temp.data+"  ");
			temp=temp.next;
		}
	}
	void del_data(int x)
	{
		while(temp.next!=head)
		{
			if(x == temp.data)
			{
				
			}
			else
			{
				System.out.println("In CLL no such data is present");
			}
		}
	}
	void del_pos(int pos)
	{
		int count = 0;
		while(temp.next != head)
		{
			count++;
			if(count == pos)
			{
				
			}
			temp = temp.next;
		}
	}
	void Sorted_insert(int x)
	{
		while(temp.next!=head)
		{
			if(temp.data<x && temp.data>temp.next.data)
			{
				temp.next = new Node_SLL(x);
				Node_SLL xl=temp.next;
				xl.next = temp.next.next;
			}
			temp = temp.next;
		}
		
	}
	void split_CLL()
	{
		Node_SLL fast = head; 
		Node_SLL slow = head;
		Node_SLL head1 = head;
		while(fast.next != head)
		{
			fast= fast.next.next;
			slow =slow.next;
		}
		
		Node_SLL head2 =slow.next;
		slow.next = head1;
		Node_SLL ptr = head2;
		while(ptr.next!=head)
		{
			ptr=ptr.next;
		}
		ptr.next =head2;
	}

}
