
public class Node_SLL {
	
	int data;
	Node_SLL next;
	Node_SLL()
	{
		data = 0;
		
	}
	Node_SLL(int x)
	{
		data = x;
		
	}


}
