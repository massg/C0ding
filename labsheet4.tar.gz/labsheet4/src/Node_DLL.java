
public class Node_DLL {

	int data;
	Node_DLL next;
	Node_DLL prev;
	Node_DLL()
	{
		data = 0;
		
	}
	Node_DLL(int x)
	{
		data = x;
		
	}


}
