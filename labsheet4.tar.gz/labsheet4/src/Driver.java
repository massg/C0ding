
public class Driver {
	public static void main(String[] args)
	{
		Cir_SLL cir = new Cir_SLL();
		cir.insert_after(4);
		cir.insert_after(8);
		cir.insert_after(1);
		cir.insert_after(7);
		cir.print();
	}

}
