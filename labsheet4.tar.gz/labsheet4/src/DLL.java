
public class DLL 
{
	Node_DLL head = new Node_DLL();	
	Node_DLL temp =head;
	void insert(int x)
	{
		Node_DLL new_node = new Node_DLL(3);
		head.next = new_node;
		new_node.prev = head;
		new_node.next = temp.next;
		temp.next.prev = new_node;
	}
	void delete(int x)
	{
		while(temp.next != null)
		{
			if(temp.data == x)
			{
				temp.prev.next=temp.next;
				temp.next.prev = temp.prev;
			}
			temp = temp.next;
		}
	}
	void reverse(int k)
	{
		
	}
	void 
}
