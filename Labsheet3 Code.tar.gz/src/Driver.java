
public class Driver {
	public static void main(String[] args)
	{
		Sll s = new Sll();
		s.insertlast(10);
		s.insertlast(20);
		s.insertlast(30);
		s.insertlast(40);
		s.insertlast(60);
		System.out.print("Linked list is ");
		s.print();
		s.deletepos(3);
		s.deletepos(5);
		s.sortinsert(25);
		System.out.print("Linked list is ");
		s.print();
		s.isempty();
		s.islastelement(25);
		s.islastelement(5);
		s.insertlast(30);
		System.out.print("Linked list is ");
		s.print();
		
		
		
		
		
	}

}
