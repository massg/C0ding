
public class Sll {
	Node head = new Node();
	void insertfirst(int x)
	{
		Node new_node = new Node(x);
		new_node.next = head;
		head = new_node;
	}
	void insertpos(int pos,int x)
	{
		
		if(head == null && pos !=0)
		{
			return;
		}
		else if (pos == 0)
		{
			insertfirst(x);
		}
		else
		{
			Node new_node = new Node(x);
			Node current = head;
			Node prev = null;
			int count = 0;
			while(count < pos)
			{
				prev = current;
				current = current.next;
				if(current == null) break;
				count++;
			}
			new_node.next = current;
			prev.next = new_node;
		}
	}
	void insertlast(int x)
	{
		
		if(head == null)
		{
			insertfirst(x);
		}
		else
		{
			Node new_node = new Node(x);
			Node temp = head;
			while(temp.next != null)
			{
				temp = temp.next;
			}
			temp.next = new_node;
			new_node.next= null;
		}
			
	}
	void isempty()
	{
		if(head == null)
			System.out.print("\nLinked list is empty");
		else System.out.print("\nLinked list is not empty");			
	}
	void deletefirst()
	{
		if(head == null)
			System.out.println("\nLinked list is empty");
		else 
		{
			head = head.next;
		}
	}
	void deletelast()
	{
		if(head == null)
			System.out.println("\nLinked list is empty");
		else
		{
			Node temp = head;
			while(temp.next.next!=null)
				temp = temp.next;
			temp.next = null;
		}
	}
	void deletepos(int pos)
	{
		Node temp = head;
		int count = 0;
		while(temp.next!=null)
		{
			count++;
			temp=temp.next;
		}
		if(head == null || pos == 0 || pos>count)
			System.out.println("\nLinked list is empty or invalid position");
		else
		{
			Node current = head;
			Node prev = null;
			count = 0;
			while(count< pos)
			{
				prev = current;
				current = current.next;
				while(current == null) break;
				count++;
			}
			prev.next = current.next;
		}
		
	}
	void sortinsert(int x)
	{
		if(head == null || head.data == x)
			insertfirst(x);
		else
		{
			Node new_node = new Node(x);
			Node temp = head;
			while(temp.next.data<x)
			{
				temp = temp.next;
			}
			temp.next = new_node;
			new_node.next = temp.next.next;
		}
	}
	void islastelement(int x)
	{
		Node temp = head;
		if(head == null)
			System.out.print("\nEmpty list");
		else
		{
			while(temp.next!= null)
				temp = temp.next;
			if(x == temp.data)
				System.out.print("\nLast element is  "+x);
			else System.out.println("\nLast element is not "+x);
				
		}
	}
	void print()
	{
		Node temp = head.next;
		while(temp != null)
		{
			System.out.print(" "+temp.data);
			temp = temp.next;
		}
	}
	

}
