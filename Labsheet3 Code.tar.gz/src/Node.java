
public class Node {
	int data;
	Node next;
	Node()
	{
		data = 0;
		next = null;
	}
	Node(int x)
	{
		data = x;
		next = null;
	}

}
